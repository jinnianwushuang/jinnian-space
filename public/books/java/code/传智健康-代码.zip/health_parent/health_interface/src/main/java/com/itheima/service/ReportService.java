package com.itheima.service;

import java.util.Map;

public interface ReportService {
    public Map<String,Object> getBusinessReportData()throws Exception;
}
