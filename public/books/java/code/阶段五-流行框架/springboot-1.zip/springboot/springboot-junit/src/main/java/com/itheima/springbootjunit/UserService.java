package com.itheima.springbootjunit;


import org.springframework.stereotype.Service;

@Service
public class UserService {

    public void show(){
        System.out.println("show....");
    }
}
