package com.itheima.springbootconfiginner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootConfigInnerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootConfigInnerApplication.class, args);
    }

}
