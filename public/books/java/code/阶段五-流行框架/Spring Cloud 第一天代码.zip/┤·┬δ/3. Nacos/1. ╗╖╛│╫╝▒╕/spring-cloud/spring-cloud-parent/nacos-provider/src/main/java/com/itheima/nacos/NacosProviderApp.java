package com.itheima.nacos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NacosProviderApp {

    public static void main(String[] args) {

        SpringApplication.run(NacosProviderApp.class,args);
    }
}
