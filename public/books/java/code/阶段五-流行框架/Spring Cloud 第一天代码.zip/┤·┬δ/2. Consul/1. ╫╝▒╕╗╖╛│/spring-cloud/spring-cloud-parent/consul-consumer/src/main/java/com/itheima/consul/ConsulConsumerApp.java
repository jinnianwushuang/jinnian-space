package com.itheima.consul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ConsulConsumerApp {

    public static void main(String[] args) {
        SpringApplication.run(ConsulConsumerApp.class,args);
    }
}
