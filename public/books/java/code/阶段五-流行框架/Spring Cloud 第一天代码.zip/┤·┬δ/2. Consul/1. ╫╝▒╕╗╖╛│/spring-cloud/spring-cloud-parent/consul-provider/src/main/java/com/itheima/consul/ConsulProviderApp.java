package com.itheima.consul;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsulProviderApp {

    public static void main(String[] args) {
        SpringApplication.run(ConsulProviderApp.class,args);
    }
}
