package com.itheima.springbootcondition.domain;

public class User {
}
