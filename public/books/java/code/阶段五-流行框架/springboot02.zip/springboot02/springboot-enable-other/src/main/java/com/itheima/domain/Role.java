package com.itheima.domain;

public class Role {
}
