package com.itheima.dao;

public interface AccountDao {
    public void save();
}
