package com.itheima.dao.impl;

import com.itheima.dao.AccountDao;

public class AccountDaoImpl implements AccountDao {

    public void save() {
        System.out.println("book dao running...");
    }

}
