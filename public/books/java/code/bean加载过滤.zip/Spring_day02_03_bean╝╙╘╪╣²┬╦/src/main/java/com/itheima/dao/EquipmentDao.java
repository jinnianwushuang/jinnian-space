package com.itheima.dao;

public interface EquipmentDao  {
    public void save();
}
