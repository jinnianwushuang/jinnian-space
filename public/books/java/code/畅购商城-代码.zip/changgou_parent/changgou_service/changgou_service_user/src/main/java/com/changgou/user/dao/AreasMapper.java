package com.changgou.user.dao;

import com.changgou.user.pojo.Areas;
import tk.mybatis.mapper.common.Mapper;

public interface AreasMapper extends Mapper<Areas> {

}
