package com.changgou.goods.dao;

import com.changgou.goods.pojo.Category;
import tk.mybatis.mapper.common.Mapper;

public interface CategoryMapper extends Mapper<Category> {

}
