package com.changgou.goods.dao;

import com.changgou.goods.pojo.Para;
import tk.mybatis.mapper.common.Mapper;

public interface ParaMapper extends Mapper<Para> {

}
