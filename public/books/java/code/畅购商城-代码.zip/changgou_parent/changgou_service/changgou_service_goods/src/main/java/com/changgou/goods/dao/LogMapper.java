package com.changgou.goods.dao;

import com.changgou.goods.pojo.Log;
import tk.mybatis.mapper.common.Mapper;

public interface LogMapper extends Mapper<Log> {

}
