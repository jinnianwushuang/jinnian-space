package com.changgou.goods.dao;

import com.changgou.goods.pojo.Album;
import tk.mybatis.mapper.common.Mapper;

public interface AlbumMapper extends Mapper<Album> {

}
