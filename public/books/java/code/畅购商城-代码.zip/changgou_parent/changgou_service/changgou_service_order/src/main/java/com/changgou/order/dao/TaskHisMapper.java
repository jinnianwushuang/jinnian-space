package com.changgou.order.dao;

import com.changgou.order.pojo.TaskHis;
import tk.mybatis.mapper.common.Mapper;

public interface TaskHisMapper extends Mapper<TaskHis> {
}
