package com.changgou.order.dao;

import com.changgou.order.pojo.Preferential;
import tk.mybatis.mapper.common.Mapper;

public interface PreferentialMapper extends Mapper<Preferential> {

}
