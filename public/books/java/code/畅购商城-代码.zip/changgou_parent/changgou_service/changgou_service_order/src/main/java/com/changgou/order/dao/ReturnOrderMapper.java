package com.changgou.order.dao;

import com.changgou.order.pojo.ReturnOrder;
import tk.mybatis.mapper.common.Mapper;

public interface ReturnOrderMapper extends Mapper<ReturnOrder> {

}
