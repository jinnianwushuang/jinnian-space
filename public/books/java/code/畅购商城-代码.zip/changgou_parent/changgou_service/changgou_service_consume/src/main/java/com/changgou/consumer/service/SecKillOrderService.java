package com.changgou.consumer.service;

import com.changgou.seckill.pojo.SeckillOrder;

public interface SecKillOrderService {

    int createOrder(SeckillOrder seckillOrder);
}
