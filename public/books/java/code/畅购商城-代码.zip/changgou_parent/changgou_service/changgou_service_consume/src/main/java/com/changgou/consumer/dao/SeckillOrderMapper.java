package com.changgou.consumer.dao;

import com.changgou.seckill.pojo.SeckillOrder;
import tk.mybatis.mapper.common.Mapper;


public interface SeckillOrderMapper extends Mapper<SeckillOrder> {

  
}
