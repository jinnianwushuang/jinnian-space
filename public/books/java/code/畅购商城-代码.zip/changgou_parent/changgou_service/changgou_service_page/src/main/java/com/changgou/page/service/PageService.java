package com.changgou.page.service;

public interface PageService {

    //生成静态化页面
    void generateHtml(String spuId);
}
