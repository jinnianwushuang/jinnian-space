package com.itheima.service.front;

import com.itheima.domain.front.ExamQuestion;
import com.itheima.domain.store.Question;

import java.util.List;

public interface ExamService {

    List<Question> getPaper();

    boolean applyPaper(String memberId, List<ExamQuestion> examQuestionList);
}
