package com.itheima.dao.front;

import com.itheima.domain.front.ExamQuestion;

public interface ExamQuestionDao {
    int save(ExamQuestion eq);
}
