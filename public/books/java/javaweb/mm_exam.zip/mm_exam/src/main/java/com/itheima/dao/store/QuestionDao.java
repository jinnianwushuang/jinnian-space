package com.itheima.dao.store;

import com.itheima.domain.store.Question;

import java.util.List;

public interface QuestionDao {
    List<Question> findAll();
}
