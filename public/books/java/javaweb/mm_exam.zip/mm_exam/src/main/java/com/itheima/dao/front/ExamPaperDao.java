package com.itheima.dao.front;

import com.itheima.domain.front.ExamPaper;

public interface ExamPaperDao {
    int save(ExamPaper examPaper);
}
