package com.itheima.web.controller;
//状态码类
public class Code {
    public static final Integer SUCCESS = 20000;
    public static final Integer FAIL = 50000;
    public static final Integer LOGIN_FAIL = 50101;
    public static final Integer LOGOUT_FAIL = 50102;
}
