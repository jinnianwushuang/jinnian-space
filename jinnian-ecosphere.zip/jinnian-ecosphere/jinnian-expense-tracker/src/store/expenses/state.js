export default function () {
  return {
    expenses: {
    },
  };
}
