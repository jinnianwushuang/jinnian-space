export function setExpenses(state, value) {
  state.expenses = value;
}
