export function setIsSignedIn(state, value) {
  state.isSignedIn = value;
}

export function setToolbar(state, value) {
  state.toolbar = value;
}

export function setCategoriesLoaded(state, value) {
  state.categoriesLoaded = value;
}

export function setCollectionsLoaded(state, value) {
  state.collectionsLoaded = value;
}

export function setExpensesLoaded(state, value) {
  state.expensesLoaded = value;
}

export function setCollectionUsersLoaded(state, value) {
  state.collectionUsersLoaded = value;
}

export function setUsersLoaded(state, value) {
  state.usersLoaded = value;
}
