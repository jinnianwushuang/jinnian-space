export default function () {
  return {
    categories: {
    },
  };
}
