export default function () {
  return {
    currentUser: null,
    currentCollectionUsers: {
    },
    users: {
    },
  };
}
