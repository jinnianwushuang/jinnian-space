export default function () {
  return {
    collections: {
    },
  };
}
