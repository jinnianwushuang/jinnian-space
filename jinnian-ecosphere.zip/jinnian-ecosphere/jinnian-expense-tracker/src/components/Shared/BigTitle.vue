<template>
  <div>
    <h5 class="q-mt-md q-mb-sm text-primary">
      <slot></slot>
    </h5>
    <q-separator class="q-mt-sm q-mb-lg" />
  </div>
</template>
