<template>
  <q-page>
    <q-inner-loading :showing="true">
      <q-spinner
        color="primary"
        size="3em"
        :thickness="10"
      />
    </q-inner-loading>
  </q-page>
</template>
