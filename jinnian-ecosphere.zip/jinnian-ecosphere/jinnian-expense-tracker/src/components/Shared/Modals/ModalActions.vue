<template>
  <q-card-actions
    class="q-pr-md q-pb-md no-margin"
    align="right"
  >
    <q-btn
      unelevated
      outline
      icon="edit"
      type="submit"
      color="primary"
      label="Save"
    />

  </q-card-actions>
</template>
