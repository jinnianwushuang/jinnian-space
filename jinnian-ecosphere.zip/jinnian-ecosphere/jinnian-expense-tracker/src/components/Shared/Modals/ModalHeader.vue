<template>
  <q-card-section>
    <div class="text-h6 text-primary">
      <slot></slot>
    </div>
    <q-separator />
  </q-card-section>
</template>
