export default function () {
  return {
    //
  }
}
